function changeClass() {
    const box = document.getElementById("myBox");
  
    console.log("Old class:", box.className);
  
    box.className = "new-class";
  
    console.log("New class:", box.className);
  }
  