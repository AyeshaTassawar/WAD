document.getElementById("logIn").addEventListener("click", function () {
    alert("Log In button clicked!");
  });
  