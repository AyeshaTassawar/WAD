function addNewStyle() {
    const para = document.getElementById("myPara");
    para.classList.add("new-style");  
  }
  