let n = parseInt(prompt("Enter the number of elements:"));
let userArray = [5];

for (let i = 0; i < n; i++) {
    let num = parseInt(prompt(`Enter number ${i + 1}:`));
    userArray.push(num);
}

console.log("User Entered Array:", userArray);
