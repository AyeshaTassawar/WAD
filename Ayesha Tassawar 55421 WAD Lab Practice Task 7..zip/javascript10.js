let numArray = [2, 3, 4, 5];

let product = numArray.reduce((acc, curr) => acc * curr, 1);

console.log("Product of Array Elements:", product);
