let numbersArray = [2, 3, 4, 5, 6];

numbersArray.forEach(num => {
    console.log(`Square of ${num}:`, Math.pow(num, 2));
});
