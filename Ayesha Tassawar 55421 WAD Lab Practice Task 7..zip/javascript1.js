let numbers = [10, 15, 22, 33, 40, 55, 60];
let evenNumbers = [];

for (let num of numbers) {
    if (num % 2 === 0) {
        evenNumbers.push(num);
    }
}

console.log("Even Numbers:", evenNumbers);
