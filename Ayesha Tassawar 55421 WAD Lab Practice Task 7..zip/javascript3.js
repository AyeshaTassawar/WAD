let words = ["apple", "banana", "mango", "grapes"];
let upperCaseWords = [];

for (let word of words) {
    upperCaseWords.push(word.toUpperCase());
}

console.log("Uppercase Words:", upperCaseWords);
