let softwareHouses = ["Google", "Microsoft", "Amazon", "Meta", "Apple"];

// Remove the first name
softwareHouses.shift();

// Remove middle name and add a new one
let middleIndex = Math.floor(softwareHouses.length / 2);
softwareHouses.splice(middleIndex, 1, "Tesla");

// Add a new name at the end
softwareHouses.push("IBM");

console.log("Updated Software Houses:", softwareHouses);
