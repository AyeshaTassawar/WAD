let studentMarks = [45, 78, 34, 88, 92, 49, 60];

let highMarks = studentMarks.filter(mark => mark > 50);

console.log("Marks Greater Than 50:", highMarks);
