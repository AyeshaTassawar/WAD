let arr = [34, 78, 12, 90, 5, 102, 67];
let max = -Infinity;
let min = Infinity;

for (let num of arr) {
    if (num > max) {
        max = num;
    }
    if (num < min) {
        min = num;
    }
}

console.log("Max:", max);
console.log("Min:", min);
