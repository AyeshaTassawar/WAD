function countVowels(str) {
    let count = 0;
    let vowels = "aeiouAEIOU";

    for (let char of str) {
        if (vowels.includes(char)) {
            count++;
        }
    }
    
    return count;
}

// Example usage:
console.log("Vowels in 'Hello World':", countVowels("Hello World"));
console.log("Vowels in 'JavaScript':", countVowels("JavaScript"));
console.log("Vowels in 'Riphah University':", countVowels("Riphah University"));
