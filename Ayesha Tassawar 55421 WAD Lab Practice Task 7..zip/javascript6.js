const countVowelsArrow = (str) => {
    return str.split("").filter(char => "aeiouAEIOU".includes(char)).length;
};

console.log("Number of Vowels (Arrow Function):", countVowelsArrow("JavaScript"));
